<?php
session_start();
require '../includes/db.php';

// Redirect to login if not logged in or not employee
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'employee') {
    header("Location: ../index.php");
    exit();
}

$employeeId = $_SESSION['user']['id'];
$employeeName = $_SESSION['user']['name'];
$successMessage = "";
$errorMessage = "";

// Handle Clock In/Out
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    $now = date('Y-m-d H:i:s');

    if ($action === 'clock_in') {
        // Check if already clocked in without clocking out
        $check = $pdo->prepare("SELECT * FROM attendance WHERE user_id = ? AND sign_out_time IS NULL");
        $check->execute([$employeeId]);

        if ($check->rowCount() > 0) {
            $errorMessage = "You are already clocked in!";
        } else {
            $stmt = $pdo->prepare("INSERT INTO attendance (user_id, sign_in_time) VALUES (?, ?)");
            $stmt->execute([$employeeId, $now]);
            $successMessage = "Successfully clocked in!";
        }

    } elseif ($action === 'clock_out') {
        // Update the latest open clock-in
        $stmt = $pdo->prepare("UPDATE attendance SET sign_out_time = ? WHERE user_id = ? AND sign_out_time IS NULL ORDER BY id DESC LIMIT 1");
        $stmt->execute([$now, $employeeId]);

        if ($stmt->rowCount() > 0) {
            $successMessage = "Successfully clocked out!";
        } else {
            $errorMessage = "No active clock-in session found.";
        }
    }
}

    // Fetch attendance records
    $records = $pdo->prepare("SELECT * FROM attendance WHERE user_id = ? ORDER BY id DESC");
    $records->execute([$employeeId]);
    $attendanceList = $records->fetchAll(PDO::FETCH_ASSOC);

    // Check today's sign-in status
    $today = date('Y-m-d');
    $checkToday = $pdo->prepare("SELECT * FROM attendance WHERE user_id = ? AND DATE(sign_in_time) = ? ORDER BY id DESC LIMIT 1");
    $checkToday->execute([$employeeId, $today]);
    $todayRecord = $checkToday->fetch(PDO::FETCH_ASSOC);

    $showClockIn = true;
    $showClockOut = false;

    if ($todayRecord) {
        if ($todayRecord['sign_out_time'] === null) {
            // Already signed in today but not signed out
            $showClockIn = false;
            $showClockOut = true;
        } else {
            // Already signed in and out today
            $showClockIn = false;
            $showClockOut = false;
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include '../includes/header.php'; ?>
    <title>Employee Dashboard | Shift-track</title>
</head>
<body class="min-h-screen bg-gray-50">
    <div class="p-6 max-w-4xl mx-auto bg-white shadow-md rounded mt-24">
        <div class="flex items-center justify-between">
            <h1 class="text-2xl font-bold">Employee Log</h1>
            <a href="../logout.php" class="px-4 py-2 text-sm font-semibold text-white bg-red-600 rounded hover:bg-red-700">Logout</a>
        </div>
        <hr class="my-4">

        <!-- Feedback messages -->
        <?php if ($successMessage): ?>
            <div class="mb-4 p-3 bg-green-100 text-green-700 rounded"><?php echo $successMessage; ?></div>
        <?php endif; ?>
        <?php if ($errorMessage): ?>
            <div class="mb-4 p-3 bg-red-100 text-red-700 rounded"><?php echo $errorMessage; ?></div>
        <?php endif; ?>

        <!-- Clock In/Out Form -->
        <form method="POST" class="flex gap-4 mb-6">
            <?php if ($showClockIn): ?>
                <button type="submit" name="action" value="clock_in" class="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700">Clock In</button>
            <?php endif; ?>

            <?php if ($showClockOut): ?>
                <button type="submit" name="action" value="clock_out" class="px-6 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600">Clock Out</button>
            <?php endif; ?>
        </form>

        <!-- Attendance Table -->
        <h2 class="text-xl font-semibold text-gray-800 mb-2">Your Attendance Records</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full border border-gray-200 rounded">
                <thead class="bg-gray-100 text-gray-700">
                    <tr>
                        <th class="px-4 py-2 border">Date</th>
                        <th class="px-4 py-2 border">Clock In</th>
                        <th class="px-4 py-2 border">Clock Out</th>
                        <th class="px-4 py-2 border">Duration (hrs)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($attendanceList as $row): ?>
                        <tr class="text-center text-sm">
                            <td class="px-4 py-2 border"><?php echo date('Y-m-d', strtotime($row['sign_in_time'])); ?></td>
                            <td class="px-4 py-2 border"><?php echo date('H:i:s', strtotime($row['sign_in_time'])); ?></td>
                            <td class="px-4 py-2 border">
                                <?php echo $row['sign_out_time'] ? date('H:i:s', strtotime($row['sign_out_time'])) : '—'; ?>
                            </td>
                            <td class="px-4 py-2 border">
                                <?php
                                    if ($row['sign_out_time']) {
                                        $start = strtotime($row['sign_in_time']);
                                        $end = strtotime($row['sign_out_time']);
                                        echo round(($end - $start) / 3600, 2);
                                    } else {
                                        echo '—';
                                    }
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (count($attendanceList) === 0): ?>
                        <tr><td colspan="4" class="p-4 text-center text-gray-500">No attendance records yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
