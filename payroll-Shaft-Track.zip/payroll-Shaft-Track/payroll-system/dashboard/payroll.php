<?php
session_start();
require '../includes/db.php';

// Ensure only admin can access
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// Get all employees
$stmt = $pdo->prepare("SELECT id, full_name, hourly_rate FROM users WHERE role = 'employee'");
$stmt->execute();
$employees = $stmt->fetchAll();

// Fetch payroll details for each employee
$payroll = [];
foreach ($employees as $employee) {
    $userId = $employee['id'];
    $hourlyRate = $employee['hourly_rate'];
    
    // Get total hours worked this month
    $stmt = $pdo->prepare("
        SELECT SUM(TIMESTAMPDIFF(HOUR, sign_in_time, sign_out_time)) AS total_hours
        FROM attendance
        WHERE user_id = ? AND MONTH(work_date) = MONTH(CURRENT_DATE) AND YEAR(work_date) = YEAR(CURRENT_DATE)
    ");
    $stmt->execute([$userId]);
    $result = $stmt->fetch();
    $totalHours = $result['total_hours'] ?? 0;

    // Calculate payroll
    $payroll[] = [
        'name' => $employee['full_name'],
        'hours_worked' => $totalHours,
        'salary' => ($totalHours > 0) ? $totalHours * $hourlyRate : 0, // Prevent division by zero
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include '../includes/header.php'; ?>
    <title>Payroll | Admin | Shift-track</title>
</head>
<body class="min-h-screen bg-gray-100">
    <div class="p-6">
        <div class="flex items-center justify-between">
            <h1 class="text-2xl font-bold">Payroll for this Month 💸</h1>
            <a href="admin.php" class="px-4 py-2 text-sm text-white bg-blue-600 rounded hover:bg-blue-700">← Back to Dashboard</a>
        </div>
        <hr class="my-4">

        <div class="overflow-x-auto bg-white rounded shadow">
            <table class="min-w-full text-sm table-auto">
                <thead class="bg-gray-100 text-gray-700">
                    <tr>
                        <th class="px-4 py-2">Employee</th>
                        <th class="px-4 py-2">Hours Worked</th>
                        <th class="px-4 py-2">Hourly Rate</th>
                        <th class="px-4 py-2">Salary</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($payroll) > 0): ?>
                        <?php foreach ($payroll as $row): ?>
                            <tr class="border-b">
                                <td class="px-4 py-2"><?php echo htmlspecialchars($row['name']); ?></td>
                                <td class="px-4 py-2 text-center"><?php echo $row['hours_worked']; ?> hrs</td>
                                <td class="px-4 py-2 text-center">K<?php echo $row['hours_worked'] > 0 ? number_format($row['salary'], 2) : '0.00'; ?></td>
                                <td class="px-4 py-2 text-center">K<?php echo number_format($row['salary'], 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="px-4 py-4 text-center text-gray-500">No payroll data available.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
