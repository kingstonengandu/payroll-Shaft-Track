<?php
session_start();
require '../includes/db.php';

// Ensure only admin can access
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// Fetch all attendance logs
$stmt = $pdo->prepare("
    SELECT a.*, u.full_name 
    FROM attendance a 
    JOIN users u ON a.user_id = u.id 
    ORDER BY a.work_date DESC, a.sign_in_time DESC
");
$stmt->execute();
$logs = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include '../includes/header.php'; ?>
    <title>Attendance Logs | Admin | Shift-track</title>
</head>
<body class="min-h-screen bg-gray-100">
    <div class="p-6">
        <div class="flex items-center justify-between">
            <h1 class="text-2xl font-bold">Attendance Logs 📋</h1>
            <a href="admin.php" class="px-4 py-2 text-sm text-white bg-blue-600 rounded hover:bg-blue-700">← Back to Dashboard</a>
        </div>
        <hr class="my-4">

        <div class="overflow-x-auto bg-white rounded shadow">
            <table class="min-w-full text-sm table-auto">
                <thead class="bg-gray-100 text-gray-700">
                    <tr>
                        <th class="px-4 py-2">Employee</th>
                        <th class="px-4 py-2">Date</th>
                        <th class="px-4 py-2">Sign In</th>
                        <th class="px-4 py-2">Sign Out</th>
                        <th class="px-4 py-2">Hours Worked</th>
                        <th class="px-4 py-2">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($logs) > 0): ?>
                        <?php foreach ($logs as $row): ?>
                            <tr class="border-b">
                                <td class="px-4 py-2"><?php echo htmlspecialchars($row['full_name']); ?></td>
                                <td class="px-4 py-2"><?php echo $row['work_date']; ?></td>
                                <td class="px-4 py-2"><?php echo $row['sign_in_time'] ? date('h:i A', strtotime($row['sign_in_time'])) : '-'; ?></td>
                                <td class="px-4 py-2"><?php echo $row['sign_out_time'] ? date('h:i A', strtotime($row['sign_out_time'])) : '-'; ?></td>
                                <td class="px-4 py-2 text-center">
                                    <?php
                                    if ($row['sign_in_time'] && $row['sign_out_time']) {
                                        $start = new DateTime($row['sign_in_time']);
                                        $end = new DateTime($row['sign_out_time']);
                                        $interval = $start->diff($end);
                                        echo $interval->format('%h hrs %i min');
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                                <td class="px-4 py-2">
                                    <span class="px-2 py-1 text-xs font-semibold text-white rounded
                                        <?php echo $row['status'] === 'Signed In' ? 'bg-yellow-500' : 'bg-green-600'; ?>">
                                        <?php echo $row['status']; ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="px-4 py-4 text-center text-gray-500">No attendance logs found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
