<?php
session_start();
require 'includes/db.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'name' => $user['full_name'],
            'role' => $user['role']
        ];
        if ($user['role'] == 'admin') {
            header("Location: dashboard/admin.php");
        } else {
            header("Location: dashboard/employee.php");
        }
        exit();
    } else {
        $errors[] = "Invalid email or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include 'includes/header.php'; ?>
    <title>Shift-track | Employment & Payroll MS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .hero-1{
            background-image: url("./bg.jpg");
            background-size: cover;
        }
    </style>
</head>
<body class="bg-gray-50 text-gray-800">

<!-- Navbar -->
<header class="bg-white shadow-sm sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
        <img src="./logo.png" class=" w-30 h-20">
        <nav>
            <ul class="flex gap-6 text-sm font-medium">
                <li><a href="#" class="hover:text-blue-600">Home</a></li>
                <li><a href="#features" class="hover:text-blue-600">Features</a></li>
                <li><a href="#how" class="hover:text-blue-600">How it works</a></li>
                <li><a href="#testimonials" class="hover:text-blue-600">Testimonials</a></li>
                <li><a href="#login" class="hover:text-blue-600">Login</a></li>
            </ul>
        </nav>
    </div>
</header>

<section class=" hero-1 py-20 text-center">
    <div class="max-w-3xl mx-auto px-4">
        <h2 class="text-4xl font-bold text-blue-200 mb-4">Smart Employment & Payroll Management</h2>
        <p class="text-gray-300 text-lg mb-6">Effortlessly manage your workforce with automation, analytics, and accuracy.</p>
        <a href="#login" class="inline-block px-6 py-3 bg-blue-600 text-white font-medium rounded hover:bg-blue-700 transition">Login Now</a>
    </div>
    
</section>

<section id="features" class="py-20 bg-white">
    <div class="max-w-6xl mx-auto px-6 text-center">
        <h3 class="text-3xl font-semibold mb-12 text-blue-700">Platform Features</h3>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div class="p-6 bg-gray-100 rounded-lg shadow">
                <h4 class="font-semibold text-lg mb-2">Attendance Tracking</h4>
                <p>Real-time tracking of employee shifts and breaks.</p>
            </div>
            <div class="p-6 bg-gray-100 rounded-lg shadow">
                <h4 class="font-semibold text-lg mb-2">Payroll Automation</h4>
                <p>Generate payslips and calculate salaries in one click.</p>
            </div>
            <div class="p-6 bg-gray-100 rounded-lg shadow">
                <h4 class="font-semibold text-lg mb-2">Dashboards</h4>
                <p>Admin and employee views to monitor productivity and payments.</p>
            </div>
        </div>
    </div>
</section>

<!-- How it Works -->
<section id="how" class="py-20 bg-blue-50">
    <div class="max-w-6xl mx-auto grid md:grid-cols-2 items-center gap-12 px-6">
        <div>
            <h3 class="text-3xl font-bold text-blue-700 mb-4">How It Works</h3>
            <p class="text-gray-700 mb-4">Shift-track makes managing employees and payroll as easy as a few clicks. From clock-ins to payslips, we automate your workflow.</p>
            <ul class="list-disc list-inside text-left text-gray-600 space-y-2">
                <li>Track daily attendance and working hours</li>
                <li>Generate monthly payroll and export reports</li>
            </ul>
        </div>
        <div>
        </div>
    </div>
</section>

<!-- Testimonials -->
<section id="testimonials" class="py-20 bg-white text-center">
    <div class="max-w-4xl mx-auto px-6">
        <h3 class="text-3xl font-bold text-blue-700 mb-10">What Our Users Say</h3>
        <div class="grid gap-10 md:grid-cols-2">
            <div class="bg-gray-100 p-6 rounded-lg shadow">
                <p class="text-gray-700 italic">"Shift-track changed how we manage our HR and payroll. It’s reliable and user-friendly!"</p>
                <div class="flex items-center justify-center mt-4 gap-3">
                    <span class="font-medium">Sarah M., HR Manager</span>
                </div>
            </div>
            <div class="bg-gray-100 p-6 rounded-lg shadow">
                <p class="text-gray-700 italic">"As an employee, I can track my hours and see my payslips easily. It’s seamless!"</p>
                <div class="flex items-center justify-center mt-4 gap-3">
                    <span class="font-medium">James T., Engineer</span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Login -->
<section id="login" class="py-20 bg-gray-50">
    <div class="max-w-md mx-auto bg-white p-8 rounded-lg shadow-lg">
        <h3 class="text-2xl font-bold text-center text-blue-700 mb-6">Login to Shift-track</h3>

        <?php if ($errors): ?>
            <div class="mb-4 text-red-600 bg-red-100 p-3 rounded">
                <?php foreach ($errors as $error) echo "<p>$error</p>"; ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-4">
            <div>
                <label class="block mb-1 text-sm font-medium text-gray-700">Email</label>
                <input type="email" name="email" required class="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
                <label class="block mb-1 text-sm font-medium text-gray-700">Password</label>
                <input type="password" name="password" required class="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <button type="submit" class="w-full px-4 py-2 font-semibold text-white bg-blue-600 rounded hover:bg-blue-700">Login</button>
        </form>
    </div>
</section>

<!-- Footer -->
<footer class="bg-gray-800 text-white py-6 text-center">
    <p>&copy; <?php echo date('Y'); ?> Shift-track Inc. All rights reserved.</p>
</footer>

</body>
</html>
